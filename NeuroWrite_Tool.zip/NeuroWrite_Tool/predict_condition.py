import pandas as pd
import numpy as np
from feature_extraction import extract_features
from sklearn.preprocessing import StandardScaler
from sklearn.metrics.pairwise import euclidean_distances


def predict_condition(uploaded_file_path):
    reference_df = pd.read_csv("output/reference_features.csv")

    feature_cols = [
        "Mean_FSR",
        "SD_FSR",
        "Max_FSR",
        "Pressure_Imbalance",
        "Mean_AccMag",
        "SD_AccMag",
        "Mean_GyroMag",
        "SD_GyroMag",
        "Mean_Jerk",
        "Max_Jerk",
        "Pressure_Motion_Corr"
    ]

    reference_df = reference_df.dropna()

    uploaded_features = extract_features(uploaded_file_path)
    uploaded_df = pd.DataFrame([uploaded_features])

    scaler = StandardScaler()

    X_reference = scaler.fit_transform(reference_df[feature_cols])
    X_uploaded = scaler.transform(uploaded_df[feature_cols])

    distances = euclidean_distances(X_uploaded, X_reference)[0]

    reference_df["Distance"] = distances

    group_distance = reference_df.groupby("Group")["Distance"].mean()

    predicted_group = group_distance.idxmin()

    inverse_distances = 1 / (group_distance + 1e-6)
    probabilities = inverse_distances / inverse_distances.sum()

    confidence = probabilities[predicted_group] * 100

    return predicted_group, confidence, uploaded_features, group_distance