import os
import pandas as pd
from feature_extraction import extract_features


REFERENCE_FOLDER = "reference_data"
OUTPUT_FOLDER = "output"
OUTPUT_FILE = os.path.join(
    OUTPUT_FOLDER,
    "reference_features.csv"
)


def identify_group(filename):
    name = filename.lower()

    if "adhd" in name:
        return "ADHD"

    if "dysgraphia" in name:
        return "Dysgraphia"

    if "control" in name or "normal" in name:
        return "Control"

    return "Unknown"


def main():
    # Check reference folder
    if not os.path.exists(REFERENCE_FOLDER):
        print(
            f"Error: Folder '{REFERENCE_FOLDER}' does not exist."
        )
        return

    # Create output folder if missing
    os.makedirs(OUTPUT_FOLDER, exist_ok=True)

    rows = []
    failed_files = []

    files = sorted(os.listdir(REFERENCE_FOLDER))

    csv_files = [
        file for file in files
        if file.lower().endswith(".csv")
    ]

    if not csv_files:
        print(
            "No CSV files were found in the reference_data folder."
        )
        return

    print(f"Found {len(csv_files)} CSV files.")
    print()

    for filename in csv_files:
        file_path = os.path.join(
            REFERENCE_FOLDER,
            filename
        )

        print(f"Processing: {filename}")

        try:
            features = extract_features(file_path)

            group = identify_group(filename)

            features["File"] = filename
            features["Group"] = group

            rows.append(features)

            print(f"Success — Group: {group}")

        except Exception as error:
            failed_files.append(
                {
                    "File": filename,
                    "Error": str(error)
                }
            )

            print(f"Skipped — {error}")

        print()

    if not rows:
        print(
            "No valid reference files were processed."
        )
        return

    reference_df = pd.DataFrame(rows)

    # Put File and Group first
    first_columns = ["File", "Group"]

    remaining_columns = [
        column for column in reference_df.columns
        if column not in first_columns
    ]

    reference_df = reference_df[
        first_columns + remaining_columns
    ]

    reference_df.to_csv(
        OUTPUT_FILE,
        index=False
    )

    print("-----------------------------------")
    print("Reference dataset created successfully.")
    print(f"Saved to: {OUTPUT_FILE}")
    print(f"Successful files: {len(rows)}")
    print(f"Failed files: {len(failed_files)}")
    print("-----------------------------------")
    print()
    print(reference_df)

    if failed_files:
        failed_df = pd.DataFrame(failed_files)

        failed_path = os.path.join(
            OUTPUT_FOLDER,
            "failed_reference_files.csv"
        )

        failed_df.to_csv(
            failed_path,
            index=False
        )

        print()
        print(
            "Some files were skipped. "
            f"Details saved to: {failed_path}"
        )


if __name__ == "__main__":
    main()