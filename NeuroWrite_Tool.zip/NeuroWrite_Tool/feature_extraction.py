import pandas as pd
import numpy as np
from pathlib import Path


def extract_features(file_path):
    file_path = Path(file_path)

    # Check that the file exists
    if not file_path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    # Read CSV
    df = pd.read_csv(file_path)

    # Remove unwanted spaces from column names
    df.columns = df.columns.str.strip()

    required_cols = [
        "Timestamp_ms",
        "FSR1",
        "FSR2",
        "AccX",
        "AccY",
        "AccZ",
        "GyroX",
        "GyroY",
        "GyroZ"
    ]

    # Check for missing required columns
    missing_cols = [
        column for column in required_cols
        if column not in df.columns
    ]

    if missing_cols:
        raise ValueError(
            f"{file_path.name} is missing these columns: "
            f"{', '.join(missing_cols)}"
        )

    # Convert required columns to numbers.
    # Invalid text values become NaN.
    for column in required_cols:
        df[column] = pd.to_numeric(
            df[column],
            errors="coerce"
        )

    # Remove rows only when required sensor columns are missing.
    # Do not remove rows because optional columns contain blanks.
    df = df.dropna(subset=required_cols).copy()

    # Check whether valid data remains
    if df.empty:
        raise ValueError(
            f"{file_path.name} contains no valid sensor rows "
            "after cleaning."
        )

    # Sort by timestamp
    df = df.sort_values("Timestamp_ms").reset_index(drop=True)

    # Remove duplicate timestamps
    df = df.drop_duplicates(
        subset=["Timestamp_ms"],
        keep="first"
    ).reset_index(drop=True)

    if len(df) < 3:
        raise ValueError(
            f"{file_path.name} has too few valid rows. "
            "At least 3 rows are required."
        )

    # Time in seconds
    df["Time_s"] = (
        df["Timestamp_ms"] -
        df["Timestamp_ms"].iloc[0]
    ) / 1000.0

    # Pressure calculations
    df["FSR_Total"] = df["FSR1"] + df["FSR2"]
    df["FSR_Diff"] = np.abs(df["FSR1"] - df["FSR2"])

    # Acceleration magnitude
    df["AccMag"] = np.sqrt(
        df["AccX"] ** 2 +
        df["AccY"] ** 2 +
        df["AccZ"] ** 2
    )

    # Gyroscope magnitude
    df["GyroMag"] = np.sqrt(
        df["GyroX"] ** 2 +
        df["GyroY"] ** 2 +
        df["GyroZ"] ** 2
    )

    # Calculate jerk
    dt = df["Time_s"].diff()

    # Replace invalid or zero time differences
    dt = dt.where(dt > 0, np.nan)

    df["Jerk"] = (
        df["AccMag"].diff().abs() / dt
    )

    # Remove infinite values created during division
    df["Jerk"] = df["Jerk"].replace(
        [np.inf, -np.inf],
        np.nan
    )

    # Pressure-motion correlation
    pressure_motion_corr = df["FSR_Total"].corr(
        df["AccMag"]
    )

    # In rare cases correlation cannot be calculated
    if pd.isna(pressure_motion_corr):
        pressure_motion_corr = 0.0

    valid_jerk = df["Jerk"].dropna()

    if valid_jerk.empty:
        mean_jerk = 0.0
        max_jerk = 0.0
    else:
        mean_jerk = valid_jerk.mean()
        max_jerk = valid_jerk.max()

    features = {
        "Mean_FSR": df["FSR_Total"].mean(),
        "SD_FSR": df["FSR_Total"].std(),
        "Max_FSR": df["FSR_Total"].max(),
        "Pressure_Imbalance": df["FSR_Diff"].mean(),

        "Mean_AccMag": df["AccMag"].mean(),
        "SD_AccMag": df["AccMag"].std(),

        "Mean_GyroMag": df["GyroMag"].mean(),
        "SD_GyroMag": df["GyroMag"].std(),

        "Mean_Jerk": mean_jerk,
        "Max_Jerk": max_jerk,

        "Pressure_Motion_Corr": pressure_motion_corr
    }

    return features