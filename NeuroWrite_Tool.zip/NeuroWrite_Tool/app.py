import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import tempfile
from predict_condition import predict_condition

st.set_page_config(
    page_title="NeuroWrite Screening Tool",
    layout="wide"
)

st.title("NeuroWrite Sensor-Based Handwriting Screening Tool")

st.warning(
    "This tool is not a medical diagnosis. It only compares handwriting sensor patterns "
    "with the available reference dataset and provides a screening-level indication."
)

uploaded_file = st.file_uploader("Upload handwriting CSV file", type=["csv"])

if uploaded_file is not None:
    with tempfile.NamedTemporaryFile(delete=False, suffix=".csv") as tmp:
        tmp.write(uploaded_file.read())
        tmp_path = tmp.name

    condition, confidence, features, distances = predict_condition(tmp_path)

    st.subheader("Screening Result")

    st.metric("Possible Pattern", condition)
    st.metric("Confidence", f"{confidence:.2f}%")

    st.subheader("Extracted Features")
    features_df = pd.DataFrame([features])
    st.dataframe(features_df)

    st.subheader("Group Distance Comparison")
    st.bar_chart(distances)

    st.subheader("Interpretation")

    if condition == "ADHD":
        st.write(
            "The uploaded handwriting sample shows sensor features closer to the ADHD reference group."
        )
    elif condition == "Dysgraphia":
        st.write(
            "The uploaded handwriting sample shows sensor features closer to the dysgraphia reference group."
        )
    elif condition == "Control":
        st.write(
            "The uploaded handwriting sample shows sensor features closer to the typical/control reference group."
        )
    else:
        st.write(
            "The uploaded sample could not be clearly matched with the current reference groups."
        )

    st.info(
        "Recommendation: This result should only be used as an early screening indication. "
        "Further evaluation by a qualified professional is recommended if concerns persist."
    )
else:
    st.info("Please upload a CSV file to begin analysis.")